# FK Marketing — GitHub + Netlify Auto-Deploy Setup

## Why GitHub?
Once connected, every time you update your site you just push to GitHub
and Netlify auto-deploys instantly. No more manual ZIP uploads!

## Step 1 — Create GitHub Account
1. Go to https://github.com
2. Sign up free with your Gmail

## Step 2 — Create a New Repository
1. Click the "+" icon top right → "New repository"
2. Name it: fk-marketing
3. Set to Public
4. Click "Create repository"

## Step 3 — Upload Your Files
1. Click "uploading an existing file" on the repo page
2. Drag all files from the fk-marketing-v2 folder
3. Click "Commit changes"

## Step 4 — Connect Netlify to GitHub
1. Go to app.netlify.com
2. Click your fk-marketing project
3. Go to "Project configuration" → "Build & deploy"
4. Click "Link repository"
5. Choose GitHub → select fk-marketing repo
6. Click Deploy

## Step 5 — Done! Auto-Deploy is Live
Now whenever you update files on GitHub, Netlify deploys automatically
within 30 seconds. No more ZIP files!

## How to Update the Site Going Forward
1. Go to your GitHub repo
2. Click on the file you want to edit
3. Click the pencil icon (Edit)
4. Make changes → click "Commit changes"
5. Netlify auto-deploys in ~30 seconds ⚡
